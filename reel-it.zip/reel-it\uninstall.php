<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @since      1.0.0
 * @package    Reel_It
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Delete plugin options
delete_option( 'reel_it_options' );

// Clean up any transients
delete_transient( 'reel_it_video_cache' );

// Note: We don't delete uploaded videos as they are part of the media library
// and users might want to keep them even after uninstalling the plugin