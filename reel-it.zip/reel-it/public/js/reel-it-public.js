(function () {
    'use strict';

    /**
     * Generates or retrieves a per-session anonymous ID for analytics.
     * Uses crypto.randomUUID() when available for unpredictable IDs.
     *
     * @return {string} Session identifier.
     */
    function getSessionId() {
        let sid = sessionStorage.getItem('reel_it_sid');
        if (!sid) {
            if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
                sid = 'ri_' + crypto.randomUUID();
            } else {
                sid = 'ri_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            }
            sessionStorage.setItem('reel_it_sid', sid);
        }
        return sid;
    }

    /**
     * Fire-and-forget analytics POST via fetch.
     * Why fetch instead of $.post: removes the jQuery dependency (~87KB).
     */
    function trackEvent(eventType, videoId, feedId, watchTime, productId) {
        if (typeof reel_it_public === 'undefined') return;

        const body = new URLSearchParams({
            action: 'reel_it_track_event',
            nonce: reel_it_public.nonce,
            event_type: eventType,
            video_id: videoId,
            feed_id: feedId || 0,
            watch_time: watchTime || 0,
            product_id: productId || 0,
            session_id: getSessionId()
        });

        fetch(reel_it_public.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString(),
            keepalive: true
        }).catch(function () {
            /* Why: silently swallow analytics failures — they must never break UX */
        });
    }

    class VideoSlider {
        constructor(element) {
            this.container = element;
            this.slider = element.querySelector('.reel-it-slider');
            this.feedId = element.dataset.feedId || 0;

            this.slides = Array.from(element.querySelectorAll('.reel-it-slide'));
            this.videos = Array.from(element.querySelectorAll('.reel-it-video'));
            this.prevBtn = element.querySelector('.reel-it-prev');
            this.nextBtn = element.querySelector('.reel-it-next');
            this.thumbnailBtns = Array.from(element.querySelectorAll('.reel-it-thumbnail'));

            this.currentSlide = 0;
            this.totalSlides = this.videos.length;
            this.isScrolling = false;
            this.sequentialAutoplay = true;
            this.scrollTimeout = null;
            this.trackedPlays = new Set();
            this.trackedCompletions = new Set();

            /* Why: store bound handlers so we can remove them in destroy() */
            this._boundHandlers = [];

            if (this.totalSlides === 0) return;

            this.init();
        }

        init() {
            this.slides.forEach(function (s) { s.classList.remove('active'); });

            let activeIndex = 0;
            this.videos.forEach(function (v, i) {
                if (!v.paused && !v.ended) activeIndex = i;
            });

            this.slides[activeIndex].classList.add('active');
            this.currentSlide = activeIndex;

            this.container.classList.remove('loading');
            this.bindEvents();

            const firstVideo = this.videos[0];
            if (firstVideo && !firstVideo.paused) {
                firstVideo.closest('.reel-it-video-container').classList.add('playing');
            }
        }

        /**
         * Helper to addEventListener with automatic cleanup tracking.
         */
        _on(el, event, handler, options) {
            el.addEventListener(event, handler, options);
            this._boundHandlers.push({ el, event, handler, options });
        }

        bindEvents() {
            /* 1. Play/Pause via overlay or play button */
            this._on(this.container, 'click', (e) => {
                const overlay = e.target.closest('.reel-it-video-overlay, .reel-it-play-button');
                if (!overlay) return;

                e.stopPropagation();
                e.preventDefault();

                const vc = overlay.closest('.reel-it-video-container');
                const video = vc ? vc.querySelector('video') : null;
                if (!video) return;

                if (video.paused) {
                    this.playVideo(video);
                } else {
                    video.pause();
                }
            });

            /* 2. Navigation */
            if (this.prevBtn) {
                this._on(this.prevBtn, 'click', (e) => {
                    e.preventDefault();
                    this.step(-1);
                });
            }
            if (this.nextBtn) {
                this._on(this.nextBtn, 'click', (e) => {
                    e.preventDefault();
                    this.step(1);
                });
            }

            this.thumbnailBtns.forEach((btn) => {
                this._on(btn, 'click', (e) => {
                    e.preventDefault();
                    const index = parseInt(btn.dataset.slide, 10);
                    this.navToSlide(index);
                });
            });

            /* 3. Video events */
            this.videos.forEach((video, index) => {
                this._on(video, 'play', () => this.onVideoPlay(index));
                this._on(video, 'pause', () => this.onVideoPause(index));
                this._on(video, 'ended', () => this.onVideoEnded(index));
            });

            /* 4. Scroll listener */
            this._on(this.slider, 'scroll', () => {
                if (!this.isScrolling) {
                    if (this.scrollTimeout) clearTimeout(this.scrollTimeout);
                    this.scrollTimeout = setTimeout(() => {
                        this.checkActiveSlide();
                    }, 150);
                }
            });

            /* 5. Prevent native video click-to-play */
            this._on(this.container, 'click', (e) => {
                if (e.target.classList.contains('reel-it-video')) {
                    e.preventDefault();
                }
            });

            /* 6. Product card click tracking */
            this._on(this.container, 'click', (e) => {
                const card = e.target.closest('.reel-it-product-card');
                if (!card) return;

                e.stopPropagation();

                const slide = card.closest('.reel-it-slide');
                const video = slide ? slide.querySelector('.reel-it-video') : null;
                const videoId = video ? video.dataset.videoId : null;
                const productId = card.dataset.productId || 0;

                if (videoId) {
                    trackEvent('product_click', videoId, this.feedId, 0, productId);
                }
            });

            /* 7. Keyboard navigation */
            this._on(this.container, 'keydown', (e) => {
                if (e.key === 'ArrowRight') {
                    e.preventDefault();
                    this.step(1);
                } else if (e.key === 'ArrowLeft') {
                    e.preventDefault();
                    this.step(-1);
                }
            });

            /* 8. Mute/unmute toggle */
            this._on(this.container, 'click', (e) => {
                const btn = e.target.closest('.reel-it-control-button');
                if (!btn) return;

                e.stopPropagation();
                const vc = btn.closest('.reel-it-video-container');
                const video = vc ? vc.querySelector('.reel-it-video') : null;
                if (!video) return;

                video.muted = !video.muted;
                vc.classList.toggle('muted', video.muted);
            });
        }

        playVideo(video) {
            if (!video) return;

            /* Why: mute ensures play() succeeds without prior user gesture (autoplay policy) */
            video.muted = true;

            const playPromise = video.play();
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    const vc = video.closest('.reel-it-video-container');
                    vc.classList.add('playing', 'muted');

                    const controls = vc.querySelector('.reel-it-controls-container');
                    if (controls) controls.classList.add('visible');
                }).catch(() => {
                    const vc = video.closest('.reel-it-video-container');
                    vc.classList.remove('playing');
                    video.controls = true;
                });
            }
        }

        onVideoPlay(index) {
            const video = this.videos[index];
            const vc = video.closest('.reel-it-video-container');
            const videoId = video.dataset.videoId;

            vc.classList.add('playing');

            this.slides.forEach(function (s) { s.classList.remove('active'); });
            this.slides[index].classList.add('active');
            this.currentSlide = index;

            /* Track play event (once per video per session) */
            if (videoId && !this.trackedPlays.has(videoId)) {
                this.trackedPlays.add(videoId);
                trackEvent('play', videoId, this.feedId);
            }

            /* Pause other videos */
            this.videos.forEach((otherVideo, i) => {
                if (i !== index && !otherVideo.paused) {
                    otherVideo.pause();
                    otherVideo.closest('.reel-it-video-container').classList.remove('playing');
                }
            });

            this.ensureVisible(index);
        }

        onVideoPause(index) {
            const video = this.videos[index];
            video.closest('.reel-it-video-container').classList.remove('playing');
        }

        onVideoEnded(index) {
            const video = this.videos[index];
            const videoId = video.dataset.videoId;
            const watchTime = Math.round(video.currentTime);

            if (videoId && !this.trackedCompletions.has(videoId)) {
                this.trackedCompletions.add(videoId);
                trackEvent('complete', videoId, this.feedId, watchTime);
            }

            if (this.sequentialAutoplay) {
                this.step(1, true);
            }
        }

        step(direction, autoPlay) {
            let nextIndex = this.currentSlide + direction;

            if (nextIndex >= this.totalSlides) nextIndex = 0;
            if (nextIndex < 0) nextIndex = this.totalSlides - 1;

            this.navToSlide(nextIndex, autoPlay);
        }

        navToSlide(index, autoPlay) {
            this.currentSlide = index;
            this.ensureVisible(index);

            if (autoPlay) {
                const video = this.videos[index];
                if (video) this.playVideo(video);
            }
        }

        ensureVisible(index) {
            const slide = this.slides[index];
            if (!slide) return;

            const sliderEl = this.slider;
            const slideLeft = slide.offsetLeft;
            const slideWidth = slide.offsetWidth;
            const scrollLeft = sliderEl.scrollLeft;
            const containerWidth = sliderEl.clientWidth;

            const isFullyVisible = (slideLeft >= scrollLeft) &&
                (slideLeft + slideWidth <= scrollLeft + containerWidth);

            if (!isFullyVisible) {
                this.isScrolling = true;
                const targetScroll = slideLeft - (containerWidth / 2) + (slideWidth / 2);

                sliderEl.scrollTo({
                    left: targetScroll,
                    behavior: 'smooth'
                });

                /* Why: 400ms matches the previous jQuery animate duration */
                setTimeout(() => { this.isScrolling = false; }, 400);
            }
        }

        /**
         * Updates visual active-slide state based on scroll position.
         * Only runs when no video is currently playing.
         */
        checkActiveSlide() {
            const sliderEl = this.slider;
            const center = sliderEl.scrollLeft + (sliderEl.clientWidth / 2);

            let bestIndex = this.currentSlide;
            let minDiff = Infinity;

            this.slides.forEach(function (slide, i) {
                const slideCenter = slide.offsetLeft + (slide.offsetWidth / 2);
                const diff = Math.abs(center - slideCenter);
                if (diff < minDiff) {
                    minDiff = diff;
                    bestIndex = i;
                }
            });

            const anyPlaying = this.videos.some(function (v) { return !v.paused; });

            if (!anyPlaying && bestIndex !== this.currentSlide) {
                this.currentSlide = bestIndex;
                this.slides.forEach(function (s) { s.classList.remove('active'); });
                this.slides[bestIndex].classList.add('active');
            }
        }

        destroy() {
            this._boundHandlers.forEach(function (h) {
                h.el.removeEventListener(h.event, h.handler, h.options);
            });
            this._boundHandlers = [];
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        setTimeout(function () {
            const sliders = [];

            function initSliders(context) {
                context.querySelectorAll('.reel-it-container').forEach(function (el) {
                    if (!el.dataset.reelItInitialized && el.querySelectorAll('.reel-it-video').length > 0) {
                        const slider = new VideoSlider(el);
                        sliders.push(slider);
                        el.dataset.reelItInitialized = 'true';
                    }
                });
            }

            initSliders(document);

            window.addEventListener('beforeunload', function () {
                sliders.forEach(function (s) { s.destroy(); });
            });

        }, 100);

        /* Lazy load videos and pause when out of viewport */
        if ('IntersectionObserver' in window) {
            const viewportObserver = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    const video = entry.target;
                    if (!entry.isIntersecting) {
                        if (!video.paused) {
                            video.pause();
                            video.dataset.wasPlaying = 'true';
                        }
                    } else {
                        if (video.dataset.wasPlaying === 'true') {
                            video.play().catch(function () { });
                            delete video.dataset.wasPlaying;
                        }
                    }
                });
            }, { threshold: 0.5 });

            const lazyObserver = new IntersectionObserver(function (entries, observer) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        const video = entry.target;
                        const src = video.getAttribute('data-src');
                        if (src) {
                            video.src = src;
                            video.removeAttribute('data-src');
                        }
                        observer.unobserve(video);
                    }
                });
            }, { rootMargin: '50px 0px', threshold: 0.5 });

            document.querySelectorAll('.reel-it-video').forEach(function (video) {
                viewportObserver.observe(video);
                if (video.hasAttribute('data-src')) {
                    lazyObserver.observe(video);
                }
            });
        }
    });

    /**
     * Generate poster frames client-side for videos missing a WP-generated thumbnail.
     * Why: Most shared hosts lack FFmpeg so wp_get_attachment_image_url returns false
     * for video attachments, leaving the poster attribute empty (black frame).
     * This creates a lightweight first-frame snapshot via an offscreen canvas.
     */
    function generatePosters() {
        var videos = document.querySelectorAll('.reel-it-video');
        var queue = [];
        var active = 0;
        var MAX_CONCURRENT = 2;

        videos.forEach(function (video) {
            if (video.hasAttribute('poster') && video.getAttribute('poster') !== '') {
                video.classList.add('has-poster');
                return;
            }
            var videoSrc = video.getAttribute('data-video-src');
            if (!videoSrc) return;
            queue.push({ target: video, src: videoSrc });
        });

        /** Process next item in the queue, respecting concurrency limit. */
        function processNext() {
            if (queue.length === 0 || active >= MAX_CONCURRENT) return;
            active++;
            var item = queue.shift();
            createPoster(item.target, item.src);
        }

        /**
         * Create an offscreen video, seek to ~25% of duration, paint to canvas, set poster.
         * Why 25%: skips black leader frames and intro fades common in encoded videos.
         */
        function createPoster(targetVideo, src) {
            var tmpVideo = document.createElement('video');
            /* Why preload=auto: 'metadata' doesn't guarantee decoded frame data,
               causing canplay/loadeddata to never fire on some browsers */
            tmpVideo.preload = 'auto';
            tmpVideo.muted = true;
            tmpVideo.playsInline = true;
            /* Why no crossOrigin: Local by Flywheel and some WP proxies reject
               CORS preflight on same-origin video files, silently aborting the load */
            tmpVideo.style.position = 'absolute';
            tmpVideo.style.width = '0';
            tmpVideo.style.height = '0';
            tmpVideo.style.opacity = '0';
            tmpVideo.style.pointerEvents = 'none';

            var cleaned = false;
            var timeoutId = setTimeout(function () { cleanup(); }, 10000);

            function cleanup() {
                if (cleaned) return;
                cleaned = true;
                clearTimeout(timeoutId);
                tmpVideo.removeAttribute('src');
                tmpVideo.load();
                if (tmpVideo.parentNode) tmpVideo.parentNode.removeChild(tmpVideo);
                active--;
                processNext();
            }

            /** Paint the current frame to canvas and set as poster. */
            function paintPoster() {
                try {
                    var w = tmpVideo.videoWidth || 360;
                    var h = tmpVideo.videoHeight || 640;
                    var canvas = document.createElement('canvas');
                    canvas.width = w;
                    canvas.height = h;
                    var ctx = canvas.getContext('2d');
                    ctx.drawImage(tmpVideo, 0, 0, w, h);

                    /* Why pixel check: a fully black frame (e.g. leader) would still
                       produce a valid data-URL; detect it and keep the shimmer instead */
                    var sample = ctx.getImageData(
                        Math.floor(w * 0.25), Math.floor(h * 0.25), 1, 1
                    ).data;
                    var isBlack = (sample[0] + sample[1] + sample[2]) < 30;

                    if (!isBlack) {
                        var dataUrl = canvas.toDataURL('image/jpeg', 0.7);
                        targetVideo.setAttribute('poster', dataUrl);
                    }
                    targetVideo.classList.add('has-poster');
                } catch (e) {
                    /* Why: tainted canvas or missing frame — gracefully stop shimmer */
                    targetVideo.classList.add('has-poster');
                }
                cleanup();
            }

            tmpVideo.addEventListener('canplay', function () {
                /* Seek to 25% of duration, capped at 2s, to find a meaningful frame */
                var seekTo = Math.min(tmpVideo.duration * 0.25, 2);
                if (!isFinite(seekTo) || seekTo <= 0) seekTo = 0.5;
                tmpVideo.currentTime = seekTo;
            });

            tmpVideo.addEventListener('seeked', paintPoster);

            tmpVideo.addEventListener('error', function () { cleanup(); });

            document.body.appendChild(tmpVideo);
            tmpVideo.src = src;
        }

        /* Kick off initial batch */
        for (var i = 0; i < MAX_CONCURRENT; i++) {
            processNext();
        }
    }

    /* Why setTimeout: waits for DOM to settle before poster generation */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            setTimeout(generatePosters, 200);
        });
    } else {
        setTimeout(generatePosters, 200);
    }

})();