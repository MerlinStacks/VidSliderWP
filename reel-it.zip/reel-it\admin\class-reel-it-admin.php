<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @since      1.0.0
 * @package    Reel_It
 * @subpackage Reel_It/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @since      1.0.0
 * @package    Reel_It
 * @subpackage Reel_It/admin
 */
class Reel_It_Admin {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        
        // Register AJAX handlers
        add_action( 'wp_ajax_reel_it_admin_upload_video', array( $this, 'handle_video_upload' ) );
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        wp_enqueue_style(
            $this->plugin_name,
            plugin_dir_url( __FILE__ ) . 'css/reel-it-admin.css',
            array(),
            $this->version,
            'all'
        );
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        wp_enqueue_script(
            $this->plugin_name,
            plugin_dir_url( __FILE__ ) . 'js/reel-it-admin.js',
            array( 'jquery' ),
            $this->version,
            false
        );

        // Pass AJAX URL to JavaScript
        wp_localize_script(
            $this->plugin_name,
            'reel_it_admin',
            array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce' => wp_create_nonce( 'reel_it_nonce' ),
            )
        );
    }

    /**
     * Handle video upload via AJAX
     *
     * @since    1.0.0
     */
    public function handle_video_upload() {
        check_ajax_referer( 'reel_it_nonce', 'nonce' );

        if ( ! current_user_can( 'upload_files' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to upload files.', 'reel-it' ) ) );
        }

        if ( ! isset( $_FILES['video_file'] ) ) {
            wp_send_json_error( array( 'message' => __( 'No file uploaded.', 'reel-it' ) ) );
        }

        $file = $_FILES['video_file']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        
        // Enhanced security: Validate file upload
        if ( ! is_uploaded_file( $file['tmp_name'] ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid file upload.', 'reel-it' ) ) );
        }
        
        // Check if it's a video file
        $allowed_types = array( 'video/mp4', 'video/webm', 'video/ogg', 'video/quicktime', 'video/x-msvideo' );
        
        // Enhanced MIME type validation
        if ( function_exists( 'finfo_open' ) ) {
            $finfo = finfo_open( FILEINFO_MIME_TYPE );
            if ( $finfo ) {
                $detected_mime = finfo_file( $finfo, $file['tmp_name'] );
                if ( ! in_array( $detected_mime, $allowed_types ) ) {
                    finfo_close( $finfo );
                    wp_send_json_error( array( 'message' => __( 'File type does not match extension. Please upload a valid video file.', 'reel-it' ) ) );
                }
                finfo_close( $finfo );
            }
        }
        
        if ( ! in_array( $file['type'], $allowed_types ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid file type. Please upload a video file.', 'reel-it' ) ) );
        }
        
        // Additional security: Check file content for malicious patterns
        $file_content = file_get_contents( $file['tmp_name'] );
        if ( $file_content === false || strpos( $file_content, '<?php' ) !== false ) {
            wp_send_json_error( array( 'message' => __( 'Invalid file content.', 'reel-it' ) ) );
        }

        // Handle the upload with enhanced security
        $upload_overrides = array(
            'test_form' => false,
            'mimes' => array(
                'mp4' => 'video/mp4',
                'webm' => 'video/webm',
                'ogg' => 'video/ogg',
                'mov' => 'video/quicktime',
                'avi' => 'video/x-msvideo'
            )
        );
        
        $uploaded_file = wp_handle_upload( $file, $upload_overrides );

        if ( isset( $uploaded_file['error'] ) ) {
            wp_send_json_error( array( 'message' => $uploaded_file['error'] ) );
        }

        // Insert into media library with enhanced security
        $attachment = array(
            'post_mime_type' => $uploaded_file['type'],
            'post_title' => sanitize_file_name( $uploaded_file['file'] ),
            'post_content' => '',
            'post_status' => 'inherit',
            'post_author' => get_current_user_id() // Ensure current user is the author
        );

        $attach_id = wp_insert_attachment( $attachment, $uploaded_file['file'] );
        
        if ( $attach_id ) {
            require_once( ABSPATH . 'wp-admin/includes/image.php' );
            $attach_data = wp_generate_attachment_metadata( $attach_id, $uploaded_file['file'] );
            wp_update_attachment_metadata( $attach_id, $attach_data );

            // Log the upload for security auditing - removed for production
            // error_log( sprintf( 'Reel It Admin: Video uploaded by user %d - Attachment ID: %d', get_current_user_id(), $attach_id ) );

            wp_send_json_success( array(
                'attachment_id' => $attach_id,
                'url' => $uploaded_file['url'],
                'title' => get_the_title( $attach_id )
            ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'Failed to save video to media library.', 'reel-it' ) ) );
        }
    }
}