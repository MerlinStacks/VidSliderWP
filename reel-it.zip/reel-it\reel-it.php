<?php
/**
 * Plugin Name: Reel It - A Shopable Video Slider by SLDevs
 * Plugin URI: https://customkings.com.au/reel-it
 * Description: A WordPress plugin for showcasing videos in a slider using the block editor with video upload functionality.
 * Version: 1.3.0
 * Author: SLDevs
 * Author URI: https://customkings.com.au
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: reel-it
 * Domain Path: /languages
 * Requires at least: 5.8
 * Tested up to: 6.4
 * Requires PHP: 7.4
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Currently plugin version.
 */
define( 'WP_VIDS_REEL_VERSION', '1.3.0' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-reel-it.php';

/**
 * Begins execution of the plugin.
 */
function reel_it_run() {
    $plugin = new Reel_It();
    $plugin->run();
}

reel_it_run();